<?php
  /**
   * Plugin Name:       عزيز للدفع
   * Plugin URI:        https://alammari.digital
   * Description:       يربط متجر WooCommerce بمنصة الطلبات ويزامن بيانات العملاء تلقائياً.
   * Version:           2.3.0
   * Requires at least: 5.6
   * Requires PHP:      7.4
   * Author:            العامري ديجتال
   * Author URI:        https://alammari.digital
   * License:           GPL-2.0-or-later
   * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
   * Text Domain:       aziz-checkout
   * Domain Path:       /languages
   * WC requires at least: 5.0
   * WC tested up to:   8.9
   */

  defined( 'ABSPATH' ) || exit;

  define( 'AZZ_VERSION',     '2.3.0' );
  define( 'AZZ_PLUGIN_FILE', __FILE__ );
  define( 'AZZ_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
  define( 'AZZ_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
  define( 'AZZ_OPTION_KEY',  'aziz_api_key' );
  define( 'AZZ_LOG_OPTION',  'aziz_order_log' );
  // REST namespace (must match the server that calls this endpoint)
  define( 'AZZ_REST_NS',     'aziz/v1' );

  /* ──────────────────────────────────────────────────────────────────
     1.  ACTIVATION / DEACTIVATION
  ────────────────────────────────────────────────────────────────── */
  register_activation_hook( AZZ_PLUGIN_FILE, 'azz_activate' );
  register_deactivation_hook( AZZ_PLUGIN_FILE, 'azz_deactivate' );

  function azz_activate() {
      // Migrate API key from older plugin versions automatically
      if ( ! get_option( AZZ_OPTION_KEY ) ) {
          $migrated = false;
          $legacy   = [ 'fdc_azizd_api_key', 'fdc_api_key', 'fdc_rishad_api_key' ];
          foreach ( $legacy as $old ) {
              $v = get_option( $old, '' );
              if ( $v ) {
                  update_option( AZZ_OPTION_KEY, $v );
                  $migrated = true;
                  break;
              }
          }
          if ( ! $migrated ) {
              update_option( AZZ_OPTION_KEY, azz_generate_key() );
          }
      }
      if ( ! get_option( AZZ_LOG_OPTION ) ) {
          update_option( AZZ_LOG_OPTION, [] );
      }
      // Ensure REST routes are available immediately after activation
      azz_register_routes();
      flush_rewrite_rules( false );
  }

  function azz_deactivate() {
      flush_rewrite_rules( false );
  }

  function azz_generate_key(): string {
      return 'azz_' . bin2hex( random_bytes( 24 ) );
  }

  /* ──────────────────────────────────────────────────────────────────
     2.  SETTINGS PAGE  (WooCommerce → عزيز للدفع)
  ────────────────────────────────────────────────────────────────── */
  add_filter( 'woocommerce_settings_tabs_array', 'azz_add_settings_tab', 60 );
  function azz_add_settings_tab( $tabs ) {
      $tabs['aziz_checkout'] = '⚡ عزيز للدفع';
      return $tabs;
  }

  add_action( 'woocommerce_settings_tabs_aziz_checkout', 'azz_settings_page' );
  function azz_settings_page() {
      $api_key      = get_option( AZZ_OPTION_KEY, '' );
      $endpoint_url = get_rest_url( null, AZZ_REST_NS . '/sync-order' );
      $store_url    = get_option( 'azz_store_url', '' );
      $enabled      = get_option( 'azz_enabled', 'yes' );
      $log          = array_slice( array_reverse( (array) get_option( AZZ_LOG_OPTION, [] ) ), 0, 20 );

      $wp_enabled  = get_option( 'azz_wp_enabled', 'no' );
      $wp_apikey   = get_option( 'azz_wp_apikey', '' );
      $wp_phones   = get_option( 'azz_wp_phones', '' );
      $wp_msg      = get_option( 'azz_wp_message', "لديك طلب جديد من {customer_name}، رقم الطلب: ({order_ref})، الباقة: {product_name}، المبلغ: {amount} {currency}، رقم التواصل: {customer_phone}." );

      if ( isset( $_POST['azz_save'] ) && check_admin_referer( 'azz_settings' ) ) {
          $enabled   = sanitize_text_field( $_POST['azz_enabled'] ?? 'no' );
          $store_url = esc_url_raw( $_POST['azz_store_url'] ?? '' );
          update_option( 'azz_enabled',   $enabled );
          update_option( 'azz_store_url', $store_url );

          // Whatsiplus settings
          $wp_enabled  = sanitize_text_field( $_POST['azz_wp_enabled'] ?? 'no' );
          $wp_apikey   = sanitize_text_field( $_POST['azz_wp_apikey'] ?? '' );
          $wp_phones   = sanitize_text_field( $_POST['azz_wp_phones'] ?? '' );
          $wp_msg      = sanitize_textarea_field( $_POST['azz_wp_message'] ?? '' );
          update_option( 'azz_wp_enabled', $wp_enabled );
          update_option( 'azz_wp_apikey',  $wp_apikey );
          update_option( 'azz_wp_phones',  $wp_phones );
          update_option( 'azz_wp_message', $wp_msg );

          echo '<div class="updated"><p>✅ تم حفظ الإعدادات.</p></div>';
      }

      if ( isset( $_POST['azz_regen'] ) && check_admin_referer( 'azz_settings' ) ) {
          $api_key = azz_generate_key();
          update_option( AZZ_OPTION_KEY, $api_key );
          echo '<div class="updated"><p>🔑 تم توليد مفتاح API جديد. حدّثه في لوحة التحكم.</p></div>';
      }
      ?>
      <style>
          .azz-box { background:#fff; border:1px solid #ddd; border-radius:8px; padding:20px; margin:15px 0; }
          .azz-box h3 { margin-top:0; color:#1e3a5f; }
          .azz-row { display:flex; gap:10px; align-items:center; margin-top:8px; }
          .azz-row input { font-family:monospace; font-size:13px; flex:1; padding:8px 12px; border:1px solid #ccc; border-radius:6px; background:#f9f9f9; }
          .azz-btn { cursor:pointer; background:#0073aa; color:#fff; border:none; padding:8px 16px; border-radius:6px; font-size:13px; }
          .azz-btn:hover { background:#005d8e; }
          .azz-log table { width:100%; border-collapse:collapse; font-size:12px; }
          .azz-log th { background:#1e3a5f; color:#fff; padding:8px; text-align:right; }
          .azz-log td { padding:7px 8px; border-bottom:1px solid #eee; }
          .azz-ok  { background:#d4edda; color:#155724; padding:2px 8px; border-radius:20px; font-size:11px; font-weight:600; }
          .azz-err { background:#f8d7da; color:#721c24; padding:2px 8px; border-radius:20px; font-size:11px; font-weight:600; }
      </style>

      <h2>⚡ عزيز للدفع — الإعدادات</h2>

      <form method="post" action="">
          <?php wp_nonce_field( 'azz_settings' ); ?>

          <div class="azz-box">
              <h3>🔗 معلومات الاتصال</h3>
              <p style="color:#555">انسخ الرابط ومفتاح API وأضفهما في لوحة التحكم تحت إعدادات بوابة الدفع المباشر.</p>
              <table class="form-table">
                  <tr>
                      <th>🌐 رابط الـ Endpoint</th>
                      <td>
                          <div class="azz-row">
                              <input type="text" id="azz_endpoint" value="<?php echo esc_attr( $endpoint_url ); ?>" readonly />
                              <button type="button" class="azz-btn" onclick="azzCopy('azz_endpoint')">نسخ</button>
                          </div>
                          <p class="description">أضف هذا الرابط في حقل "Redirect URL" في لوحة التحكم.</p>
                      </td>
                  </tr>
                  <tr>
                      <th>🔑 مفتاح API</th>
                      <td>
                          <div class="azz-row">
                              <input type="text" id="azz_api_key_display" value="<?php echo esc_attr( $api_key ); ?>" readonly />
                              <button type="button" class="azz-btn" onclick="azzCopy('azz_api_key_display')">نسخ</button>
                          </div>
                          <p class="description">أضف هذا المفتاح في حقل "API Key" في لوحة التحكم.</p>
                          <button type="submit" name="azz_regen" class="button" style="margin-top:8px">🔄 توليد مفتاح جديد</button>
                          <span style="color:#c0392b; font-size:12px; margin-right:8px">⚠️ بعد التوليد حدّث المفتاح في لوحة التحكم.</span>
                      </td>
                  </tr>
              </table>
          </div>

          <div class="azz-box">
              <h3>⚙️ الإعدادات العامة</h3>
              <table class="form-table">
                  <tr>
                      <th>تفعيل الإضافة</th>
                      <td>
                          <label>
                              <input type="checkbox" name="azz_enabled" value="yes" <?php checked( $enabled, 'yes' ); ?> />
                              تفعيل استقبال الطلبات
                          </label>
                      </td>
                  </tr>
                  <tr>
                      <th>🌐 رابط لوحة التحكم</th>
                      <td>
                          <input type="url" name="azz_store_url" value="<?php echo esc_attr( $store_url ); ?>"
                                 class="regular-text" placeholder="https://your-store.com" />
                          <p class="description">اختياري — يُستخدم لإرسال تأكيد الدفع تلقائياً.</p>
                      </td>
                  </tr>
              </table>
          </div>

          <div class="azz-box" style="border-color:#25d366">
              <h3 style="color:#128c7e">💬 واتساب بلس (Whatsiplus)</h3>
              <p style="color:#555">أرسل إشعار واتساب تلقائي للمسؤول عند وصول كل طلب جديد عبر خدمة <strong>Whatsiplus</strong>.</p>
              <table class="form-table">
                  <tr>
                      <th>تفعيل الإشعارات</th>
                      <td>
                          <label>
                              <input type="checkbox" name="azz_wp_enabled" value="yes" <?php checked( $wp_enabled, 'yes' ); ?> />
                              تفعيل إشعارات واتساب بلس
                          </label>
                      </td>
                  </tr>
                  <tr>
                      <th>🔑 مفتاح API الخاص بـ Whatsiplus</th>
                      <td>
                          <input type="text" name="azz_wp_apikey" value="<?php echo esc_attr( $wp_apikey ); ?>"
                                 class="regular-text" placeholder="x7sglqv-p2ghw3m-nnkjgo4-vfgpbgd-olmf0vx" />
                          <p class="description">احصل على المفتاح من إعدادات Whatsiplus في WordPress ← Essential Addons ← Whatsiplus Settings.</p>
                      </td>
                  </tr>
                  <tr>
                      <th>📱 أرقام واتساب للإشعارات</th>
                      <td>
                          <input type="text" name="azz_wp_phones" value="<?php echo esc_attr( $wp_phones ); ?>"
                                 class="regular-text" placeholder="966541193972, 966501234567" />
                          <p class="description">رقم واحد أو أكثر مفصولة بفاصلة — بدون + أو رمز خاص. مثال: <code>966541193972</code></p>
                      </td>
                  </tr>
                  <tr>
                      <th>✉️ قالب رسالة الإشعار</th>
                      <td>
                          <textarea name="azz_wp_message" rows="5" style="width:100%;font-size:13px;padding:8px;border-radius:6px;border:1px solid #ccc;"><?php echo esc_textarea( $wp_msg ); ?></textarea>
                          <p class="description">
                              المتغيرات المتاحة:
                              <code>{customer_name}</code>
                              <code>{order_ref}</code>
                              <code>{wc_order_id}</code>
                              <code>{product_name}</code>
                              <code>{amount}</code>
                              <code>{currency}</code>
                              <code>{customer_phone}</code>
                              <code>{customer_email}</code>
                              <code>{date}</code>
                          </p>
                      </td>
                  </tr>
              </table>
          </div>

          <button type="submit" name="azz_save" class="button button-primary button-large">💾 حفظ الإعدادات</button>
      </form>

      <div class="azz-box azz-log" style="margin-top:30px">
          <h3>📋 آخر الطلبات المُستلمة</h3>
          <?php if ( empty( $log ) ) : ?>
              <p style="color:#888">لا توجد طلبات بعد.</p>
          <?php else : ?>
              <table>
                  <thead>
                      <tr>
                          <th>التاريخ</th><th>اسم العميل</th><th>المبلغ</th>
                          <th>رقم الطلب</th><th>رقم WooCommerce</th><th>الحالة</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ( $log as $entry ) : ?>
                          <tr>
                              <td><?php echo esc_html( $entry['date'] ?? '—' ); ?></td>
                              <td><?php echo esc_html( $entry['name'] ?? '—' ); ?></td>
                              <td><?php echo esc_html( $entry['amount'] ?? '—' ); ?> ر.س</td>
                              <td><?php echo esc_html( $entry['order_id'] ?? '—' ); ?></td>
                              <td>
                                  <?php if ( ! empty( $entry['wc_order_id'] ) ) : ?>
                                      <a href="<?php echo esc_url( admin_url( 'post.php?post=' . $entry['wc_order_id'] . '&action=edit' ) ); ?>">
                                          #<?php echo esc_html( $entry['wc_order_id'] ); ?>
                                      </a>
                                  <?php else : echo '—'; endif; ?>
                              </td>
                              <td>
                                  <?php if ( ( $entry['status'] ?? '' ) === 'ok' ) : ?>
                                      <span class="azz-ok">✅ ناجح</span>
                                  <?php else : ?>
                                      <span class="azz-err">❌ <?php echo esc_html( $entry['error'] ?? 'خطأ' ); ?></span>
                                  <?php endif; ?>
                              </td>
                          </tr>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          <?php endif; ?>
      </div>

      <p style="color:#888; font-size:12px; margin-top:20px; text-align:center">
          عزيز للدفع v<?php echo AZZ_VERSION; ?> — جميع الحقوق محفوظة لـ <strong>العامري ديجتال</strong> &copy; <?php echo date('Y'); ?>
      </p>

      <script>
      function azzCopy(id) {
          var el = document.getElementById(id);
          el.select(); el.setSelectionRange(0, 99999);
          navigator.clipboard.writeText(el.value).then(function() {
              alert('✅ تم النسخ!');
          }).catch(function() { document.execCommand('copy'); alert('✅ تم النسخ!'); });
      }
      </script>
      <?php
  }

  /* ──────────────────────────────────────────────────────────────────
     3.  REST API  —  POST /wp-json/aziz/v1/sync-order
  ────────────────────────────────────────────────────────────────── */
  add_action( 'rest_api_init', 'azz_register_routes' );
  function azz_register_routes() {
      register_rest_route( AZZ_REST_NS, '/sync-order', [
          'methods'             => WP_REST_Server::CREATABLE,
          'callback'            => 'azz_handle_sync_order',
          'permission_callback' => '__return_true',
      ] );

      register_rest_route( AZZ_REST_NS, '/ping', [
          'methods'             => WP_REST_Server::READABLE,
          'callback'            => function() {
              return new WP_REST_Response( [
                  'status'  => 'ok',
                  'plugin'  => 'عزيز للدفع',
                  'version' => AZZ_VERSION,
                  'store'   => get_bloginfo( 'name' ),
              ], 200 );
          },
          'permission_callback' => '__return_true',
      ] );
  }

  function azz_handle_sync_order( WP_REST_Request $request ): WP_REST_Response {
      if ( get_option( 'azz_enabled', 'yes' ) !== 'yes' ) {
          return azz_error( 'plugin_disabled', 'الإضافة معطّلة.', 403 );
      }

      $stored_key   = get_option( AZZ_OPTION_KEY, '' );
      $provided_key = $request->get_header( 'X-Aziz-Key' )
          ?? $request->get_header( 'X-Falcon-Key' )
          ?? $request->get_param( 'api_key' )
          ?? '';

      if ( empty( $stored_key ) || ! hash_equals( $stored_key, trim( $provided_key ) ) ) {
          azz_log( $request, null, 'error', 'مفتاح API غير صحيح' );
          return azz_error( 'invalid_api_key', 'مفتاح API غير صحيح.', 401 );
      }

      $body     = $request->get_json_params() ?: $request->get_params();
      $required = [ 'customer_name', 'customer_email', 'customer_phone', 'total_amount' ];
      foreach ( $required as $field ) {
          if ( empty( $body[ $field ] ) ) {
              return azz_error( 'missing_field', "حقل مطلوب: $field", 422 );
          }
      }

      $customer_name  = sanitize_text_field( $body['customer_name'] );
      $customer_email = sanitize_email( $body['customer_email'] );
      $customer_phone = sanitize_text_field( $body['customer_phone'] );
      $product_name   = sanitize_text_field( $body['product_name'] ?? 'اشتراك' );
      $total_amount   = floatval( $body['total_amount'] );
      $quantity       = max( 1, intval( $body['quantity'] ?? 1 ) );
      $order_ref      = sanitize_text_field( $body['falcon_order_id'] ?? $body['order_id'] ?? '' );
      $payment_gw     = sanitize_text_field( $body['payment_gateway'] ?? '' );
      $notes          = sanitize_textarea_field( $body['notes'] ?? '' );
      $return_url     = esc_url_raw( $body['return_url'] ?? '' );

      if ( $total_amount <= 0 ) return azz_error( 'invalid_amount', 'المبلغ غير صحيح.', 422 );
      if ( ! is_email( $customer_email ) ) return azz_error( 'invalid_email', 'البريد غير صحيح.', 422 );

      // Prevent duplicate orders
      if ( $order_ref ) {
          $existing = wc_get_orders( [ 'meta_key' => '_azz_order_ref', 'meta_value' => $order_ref, 'limit' => 1 ] );
          if ( ! empty( $existing ) ) {
              $wc_order = $existing[0];
              return new WP_REST_Response( [
                  'success'      => true,
                  'wc_order_id'  => $wc_order->get_id(),
                  'payment_url'  => $wc_order->get_checkout_payment_url(),
                  'order_status' => $wc_order->get_status(),
                  'message'      => 'الطلب موجود.',
              ], 200 );
          }
      }

      $customer_id = 0;
      $user = get_user_by( 'email', $customer_email );
      if ( $user ) $customer_id = $user->ID;

      $wc_order = wc_create_order( [ 'customer_id' => $customer_id ] );
      if ( is_wp_error( $wc_order ) ) {
          azz_log( $request, null, 'error', $wc_order->get_error_message() );
          return azz_error( 'order_creation_failed', $wc_order->get_error_message(), 500 );
      }

      $address = [
          'first_name' => $customer_name, 'last_name' => '', 'email' => $customer_email,
          'phone' => $customer_phone, 'address_1' => '', 'city' => '', 'country' => 'SA',
      ];
      $wc_order->set_address( $address, 'billing' );
      $wc_order->set_address( $address, 'shipping' );

      $fee = new WC_Order_Item_Fee();
      $fee->set_name( $product_name );
      $fee->set_amount( $total_amount );
      $fee->set_tax_class( '' );
      $fee->set_tax_status( 'none' );
      $fee->set_total( $total_amount );
      $wc_order->add_item( $fee );

      $wc_order->set_payment_method( 'aziz_payment' );
      $wc_order->set_payment_method_title( 'دفع مباشر' );
      $wc_order->set_currency( get_woocommerce_currency() );
      $wc_order->set_prices_include_tax( false );
      $wc_order->calculate_totals();
      $wc_order->set_status( 'pending', 'طلب مستلم' );

      $wc_order->update_meta_data( '_azz_order_ref',  $order_ref );
      $wc_order->update_meta_data( '_azz_qty',        $quantity );
      $wc_order->update_meta_data( '_azz_gateway',    $payment_gw );
      $wc_order->update_meta_data( '_azz_product',    $product_name );
      // Backward compat keys (server may check these)
      $wc_order->update_meta_data( '_falcon_order_id', $order_ref );
      $wc_order->update_meta_data( '_falcon_return_url', $return_url );
      if ( $return_url ) $wc_order->update_meta_data( '_azz_return_url', $return_url );
      if ( $notes ) $wc_order->add_order_note( 'ملاحظات: ' . $notes );

      $wc_order->save();
      $wc_order_id = $wc_order->get_id();

      azz_log( [
          'name'     => $customer_name,
          'amount'   => $total_amount,
          'order_id' => $order_ref,
          'product'  => $product_name,
          'quantity' => $quantity,
      ], $wc_order_id, 'ok' );

      // Send Whatsiplus WhatsApp notification
      azz_send_whatsiplus( [
          'customer_name'  => $customer_name,
          'customer_phone' => $customer_phone,
          'customer_email' => $customer_email,
          'order_ref'      => $order_ref,
          'wc_order_id'    => $wc_order_id,
          'product_name'   => $product_name,
          'amount'         => $total_amount,
          'currency'       => get_woocommerce_currency(),
          'date'           => wp_date( 'Y-m-d H:i' ),
      ] );

      return new WP_REST_Response( [
          'success'      => true,
          'wc_order_id'  => $wc_order_id,
          'payment_url'  => $wc_order->get_checkout_payment_url(),
          'order_key'    => $wc_order->get_order_key(),
          'order_status' => $wc_order->get_status(),
          'total'        => $wc_order->get_total(),
          'currency'     => $wc_order->get_currency(),
          'message'      => 'تم إنشاء الطلب بنجاح.',
      ], 201 );
  }

  /* ──────────────────────────────────────────────────────────────────
     4.  ALLOW IFRAME EMBEDDING
  ────────────────────────────────────────────────────────────────── */
  add_action( 'send_headers', 'azz_allow_iframe' );
  function azz_allow_iframe() {
      if ( ! function_exists( 'is_wc_endpoint_url' ) ) return;
      if ( is_checkout() || is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) {
          header_remove( 'X-Frame-Options' );
          header( 'X-Frame-Options: ALLOWALL' );
          header( 'Content-Security-Policy: frame-ancestors *' );
      }
  }

  /* ──────────────────────────────────────────────────────────────────
     5.  THANKYOU PAGE — postMessage + redirect
  ────────────────────────────────────────────────────────────────── */
  add_action( 'woocommerce_thankyou', 'azz_on_thankyou', 5 );
  function azz_on_thankyou( int $order_id ) {
      $order      = wc_get_order( $order_id );
      $order_ref  = $order ? ( $order->get_meta( '_azz_order_ref' ) ?: $order->get_meta( '_falcon_order_id' ) ) : '';
      $return_url = $order ? ( $order->get_meta( '_azz_return_url' ) ?: $order->get_meta( '_falcon_return_url' ) ) : '';
      if ( ! $order_ref ) return;

      $status  = $order->get_status();
      $is_paid = in_array( $status, [ 'processing', 'completed', 'on-hold' ], true );
      ?>
      <script>
      (function() {
          var orderRef  = '<?php echo esc_js( $order_ref ); ?>';
          var wcOrderId = <?php echo intval( $order_id ); ?>;
          var isPaid    = <?php echo $is_paid ? 'true' : 'false'; ?>;
          var returnUrl = '<?php echo esc_js( $return_url ); ?>';
          var msg = { type: 'FALCON_PAYMENT_COMPLETE', falconOrderId: orderRef, wcOrderId: wcOrderId, isPaid: isPaid };
          try { if ( window.parent && window.parent !== window ) window.parent.postMessage( msg, '*' ); } catch(e) {}
          try { if ( window.opener && !window.opener.closed ) { window.opener.postMessage( msg, '*' ); setTimeout( function() { window.close(); }, 1200 ); } } catch(e) {}
          if ( returnUrl && !window.opener && window.parent === window ) {
              setTimeout( function() { window.location.href = returnUrl; }, 2000 );
          }
      })();
      </script>
      <?php
  }

  /* ──────────────────────────────────────────────────────────────────
     6.  WEBHOOK — notify platform when order is paid
  ────────────────────────────────────────────────────────────────── */
  add_action( 'woocommerce_order_status_changed', 'azz_notify_on_payment', 10, 3 );
  function azz_notify_on_payment( int $order_id, string $from, string $to ) {
      if ( ! in_array( $to, [ 'processing', 'completed' ], true ) ) return;
      $order     = wc_get_order( $order_id );
      $order_ref = $order ? ( $order->get_meta( '_azz_order_ref' ) ?: $order->get_meta( '_falcon_order_id' ) ) : '';
      if ( ! $order_ref ) return;

      $store_url = rtrim( get_option( 'azz_store_url', '' ), '/' );
      if ( ! $store_url ) return;
      if ( strpos( $store_url, 'http' ) !== 0 ) $store_url = 'https://' . $store_url;

      wp_remote_post( $store_url . '/api/orders/direct-checkout/paid', [
          'body'     => wp_json_encode( [ 'falcon_order_id' => $order_ref, 'wc_order_id' => $order_id, 'api_key' => get_option( AZZ_OPTION_KEY, '' ) ] ),
          'headers'  => [ 'Content-Type' => 'application/json' ],
          'timeout'  => 15,
          'blocking' => false,
      ] );
  }

  /* ──────────────────────────────────────────────────────────────────
     7.  ORDER META IN ADMIN
  ────────────────────────────────────────────────────────────────── */
  add_action( 'woocommerce_admin_order_data_after_billing_address', 'azz_show_order_meta' );
  function azz_show_order_meta( WC_Order $order ) {
      $ref     = $order->get_meta( '_azz_order_ref' ) ?: $order->get_meta( '_falcon_order_id' );
      $gateway = $order->get_meta( '_azz_gateway' );
      $product = $order->get_meta( '_azz_product' ) ?: $order->get_meta( '_falcon_product' );
      if ( ! $ref ) return;
      echo '<div style="background:#e8f4ff;border:1px solid #90cdf4;border-radius:6px;padding:10px 14px;margin-top:12px;font-size:13px;">';
      echo '<strong>⚡ طلب مباشر</strong><br>';
      echo 'رقم الطلب: <code>' . esc_html( $ref ) . '</code><br>';
      if ( $product ) echo 'الباقة: ' . esc_html( $product ) . '<br>';
      if ( $gateway ) echo 'طريقة الدفع: ' . esc_html( $gateway );
      echo '</div>';
  }

  /* ──────────────────────────────────────────────────────────────────
     8.  WHATSIPLUS — WhatsApp notification on new order
  ────────────────────────────────────────────────────────────────── */
  function azz_send_whatsiplus( array $data ) {
      if ( get_option( 'azz_wp_enabled', 'no' ) !== 'yes' ) return;

      $apikey  = trim( get_option( 'azz_wp_apikey', '' ) );
      $phones  = trim( get_option( 'azz_wp_phones', '' ) );
      $template = get_option( 'azz_wp_message', '' );

      if ( ! $apikey || ! $phones || ! $template ) return;

      // Replace template variables
      $message = strtr( $template, [
          '{customer_name}'  => $data['customer_name']  ?? '',
          '{order_ref}'      => $data['order_ref']      ?? '',
          '{wc_order_id}'    => $data['wc_order_id']    ?? '',
          '{product_name}'   => $data['product_name']   ?? '',
          '{amount}'         => $data['amount']         ?? '',
          '{currency}'       => $data['currency']       ?? '',
          '{customer_phone}' => $data['customer_phone'] ?? '',
          '{customer_email}' => $data['customer_email'] ?? '',
          '{date}'           => $data['date']           ?? '',
      ] );

      // Parse phone list — remove spaces, split on comma or newline
      $phone_list = preg_split( '/[\s,،]+/', $phones, -1, PREG_SPLIT_NO_EMPTY );

      foreach ( $phone_list as $phone ) {
          $phone = preg_replace( '/\D/', '', $phone ); // digits only
          if ( strlen( $phone ) < 8 ) continue;

          wp_remote_post( 'https://api.whatsiplus.com/messages', [
              'headers' => [
                  'Content-Type' => 'application/json',
                  'apikey'       => $apikey,
              ],
              'body'    => wp_json_encode( [
                  'number'  => $phone,
                  'message' => $message,
              ] ),
              'timeout'  => 12,
              'blocking' => false, // fire-and-forget — don't delay order response
          ] );
      }
  }

  /* ──────────────────────────────────────────────────────────────────
     9.  HELPERS
  ────────────────────────────────────────────────────────────────── */
  function azz_error( string $code, string $message, int $status = 400 ): WP_REST_Response {
      return new WP_REST_Response( [ 'success' => false, 'code' => $code, 'message' => $message ], $status );
  }

  function azz_log( $data, ?int $wc_order_id, string $status, string $error = '' ) {
      $log   = (array) get_option( AZZ_LOG_OPTION, [] );
      $log[] = [
          'date'       => wp_date( 'Y-m-d H:i:s' ),
          'name'       => is_array( $data ) ? ( $data['name'] ?? '' ) : '',
          'amount'     => is_array( $data ) ? ( $data['amount'] ?? '' ) : '',
          'order_id'   => is_array( $data ) ? ( $data['order_id'] ?? '' ) : '',
          'wc_order_id'=> $wc_order_id,
          'status'     => $status,
          'error'      => $error,
      ];
      if ( count( $log ) > 100 ) $log = array_slice( $log, -100 );
      update_option( AZZ_LOG_OPTION, $log );
  }
  