<?php
  /**
   * Plugin Name:       ريشة للدفع
   * Plugin URI:        https://alammari.digital
   * Description:       يربط متجر WooCommerce بمنصة الطلبات ويزامن بيانات العملاء تلقائياً.
   * Version:           2.3.0
   * Requires at least: 5.6
   * Requires PHP:      7.4
   * Author:            العامري ديجتال
   * Author URI:        https://alammari.digital
   * License:           GPL-2.0-or-later
   * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
   * Text Domain:       risha-checkout
   * Domain Path:       /languages
   * WC requires at least: 5.0
   * WC tested up to:   8.9
   */

  defined( 'ABSPATH' ) || exit;

  define( 'RSH_VERSION',     '2.3.0' );
  define( 'RSH_PLUGIN_FILE', __FILE__ );
  define( 'RSH_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
  define( 'RSH_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
  define( 'RSH_OPTION_KEY',  'risha_api_key' );
  define( 'RSH_LOG_OPTION',  'risha_order_log' );
  define( 'RSH_REST_NS',     'risha/v1' );

  register_activation_hook( RSH_PLUGIN_FILE, 'rsh_activate' );
  function rsh_activate() {
      if ( ! get_option( RSH_OPTION_KEY ) ) {
          $migrated = false;
          $legacy   = [ 'fdc_rishad_api_key', 'fdc_api_key' ];
          foreach ( $legacy as $old ) {
              $v = get_option( $old, '' );
              if ( $v ) { update_option( RSH_OPTION_KEY, $v ); $migrated = true; break; }
          }
          if ( ! $migrated ) update_option( RSH_OPTION_KEY, rsh_generate_key() );
      }
      if ( ! get_option( RSH_LOG_OPTION ) ) update_option( RSH_LOG_OPTION, [] );
  }

  function rsh_generate_key(): string { return 'rsh_' . bin2hex( random_bytes( 24 ) ); }

  add_filter( 'woocommerce_settings_tabs_array', 'rsh_add_settings_tab', 61 );
  function rsh_add_settings_tab( $tabs ) { $tabs['risha_checkout'] = '✨ ريشة للدفع'; return $tabs; }

  add_action( 'woocommerce_settings_tabs_risha_checkout', 'rsh_settings_page' );
  function rsh_settings_page() {
      $api_key      = get_option( RSH_OPTION_KEY, '' );
      $endpoint_url = get_rest_url( null, RSH_REST_NS . '/sync-order' );
      $store_url    = get_option( 'rsh_store_url', '' );
      $enabled      = get_option( 'rsh_enabled', 'yes' );
      $log          = array_slice( array_reverse( (array) get_option( RSH_LOG_OPTION, [] ) ), 0, 20 );

      if ( isset( $_POST['rsh_save'] ) && check_admin_referer( 'rsh_settings' ) ) {
          $enabled   = sanitize_text_field( $_POST['rsh_enabled'] ?? 'no' );
          $store_url = esc_url_raw( $_POST['rsh_store_url'] ?? '' );
          update_option( 'rsh_enabled', $enabled ); update_option( 'rsh_store_url', $store_url );
          echo '<div class="updated"><p>✅ تم حفظ الإعدادات.</p></div>';
      }
      if ( isset( $_POST['rsh_regen'] ) && check_admin_referer( 'rsh_settings' ) ) {
          $api_key = rsh_generate_key(); update_option( RSH_OPTION_KEY, $api_key );
          echo '<div class="updated"><p>🔑 تم توليد مفتاح API جديد. حدّثه في لوحة التحكم.</p></div>';
      }
      ?>
      <style>
          .rsh-box{background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin:15px 0}
          .rsh-box h3{margin-top:0;color:#1e3a5f}
          .rsh-row{display:flex;gap:10px;align-items:center;margin-top:8px}
          .rsh-row input{font-family:monospace;font-size:13px;flex:1;padding:8px 12px;border:1px solid #ccc;border-radius:6px;background:#f9f9f9}
          .rsh-btn{cursor:pointer;background:#0073aa;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px}
          .rsh-log table{width:100%;border-collapse:collapse;font-size:12px}
          .rsh-log th{background:#1e3a5f;color:#fff;padding:8px;text-align:right}
          .rsh-log td{padding:7px 8px;border-bottom:1px solid #eee}
          .rsh-ok{background:#d4edda;color:#155724;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600}
          .rsh-err{background:#f8d7da;color:#721c24;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600}
      </style>
      <h2>✨ ريشة للدفع — الإعدادات</h2>
      <form method="post" action=""><?php wp_nonce_field( 'rsh_settings' ); ?>
          <div class="rsh-box">
              <h3>🔗 معلومات الاتصال</h3>
              <p style="color:#555">انسخ الرابط ومفتاح API وأضفهما في لوحة التحكم.</p>
              <table class="form-table">
                  <tr><th>🌐 رابط الـ Endpoint</th><td>
                      <div class="rsh-row">
                          <input type="text" id="rsh_endpoint" value="<?php echo esc_attr($endpoint_url); ?>" readonly />
                          <button type="button" class="rsh-btn" onclick="rshCopy('rsh_endpoint')">نسخ</button>
                      </div>
                  </td></tr>
                  <tr><th>🔑 مفتاح API</th><td>
                      <div class="rsh-row">
                          <input type="text" id="rsh_api_key" value="<?php echo esc_attr($api_key); ?>" readonly />
                          <button type="button" class="rsh-btn" onclick="rshCopy('rsh_api_key')">نسخ</button>
                      </div>
                      <button type="submit" name="rsh_regen" class="button" style="margin-top:8px">🔄 توليد مفتاح جديد</button>
                  </td></tr>
              </table>
          </div>
          <div class="rsh-box">
              <h3>⚙️ الإعدادات العامة</h3>
              <table class="form-table">
                  <tr><th>تفعيل الإضافة</th><td>
                      <label><input type="checkbox" name="rsh_enabled" value="yes" <?php checked($enabled,'yes'); ?> /> تفعيل استقبال الطلبات</label>
                  </td></tr>
                  <tr><th>🌐 رابط لوحة التحكم</th><td>
                      <input type="url" name="rsh_store_url" value="<?php echo esc_attr($store_url); ?>" class="regular-text" placeholder="https://your-store.com" />
                  </td></tr>
              </table>
          </div>
          <button type="submit" name="rsh_save" class="button button-primary button-large">💾 حفظ الإعدادات</button>
      </form>
      <div class="rsh-box rsh-log" style="margin-top:30px">
          <h3>📋 آخر الطلبات المُستلمة</h3>
          <?php if (empty($log)): ?><p style="color:#888">لا توجد طلبات بعد.</p><?php else: ?>
          <table><thead><tr><th>التاريخ</th><th>اسم العميل</th><th>المبلغ</th><th>رقم الطلب</th><th>WooCommerce</th><th>الحالة</th></tr></thead>
          <tbody><?php foreach($log as $e): ?>
          <tr>
              <td><?php echo esc_html($e['date']??'—'); ?></td><td><?php echo esc_html($e['name']??'—'); ?></td>
              <td><?php echo esc_html($e['amount']??'—'); ?> ر.س</td><td><?php echo esc_html($e['order_id']??'—'); ?></td>
              <td><?php if(!empty($e['wc_order_id'])): ?><a href="<?php echo esc_url(admin_url('post.php?post='.$e['wc_order_id'].'&action=edit')); ?>">#<?php echo esc_html($e['wc_order_id']); ?></a><?php else: echo '—'; endif; ?></td>
              <td><?php echo ($e['status']??'')==='ok' ? '<span class="rsh-ok">✅ ناجح</span>' : '<span class="rsh-err">❌ '.esc_html($e['error']??'خطأ').'</span>'; ?></td>
          </tr>
          <?php endforeach; ?></tbody></table>
          <?php endif; ?>
      </div>
      <p style="color:#888;font-size:12px;margin-top:20px;text-align:center">ريشة للدفع v<?php echo RSH_VERSION; ?> — العامري ديجتال &copy; <?php echo date('Y'); ?></p>
      <script>function rshCopy(id){var el=document.getElementById(id);el.select();el.setSelectionRange(0,99999);navigator.clipboard.writeText(el.value).then(function(){alert('✅ تم النسخ!');}).catch(function(){document.execCommand('copy');alert('✅ تم النسخ!');});}</script>
      <?php
  }

  add_action( 'rest_api_init', 'rsh_register_routes' );
  function rsh_register_routes() {
      register_rest_route( RSH_REST_NS, '/sync-order', [
          'methods' => WP_REST_Server::CREATABLE, 'callback' => 'rsh_handle_sync_order', 'permission_callback' => '__return_true',
      ]);
      register_rest_route( RSH_REST_NS, '/ping', [
          'methods' => WP_REST_Server::READABLE,
          'callback' => function() { return new WP_REST_Response(['status'=>'ok','plugin'=>'ريشة للدفع','version'=>RSH_VERSION,'store'=>get_bloginfo('name')], 200); },
          'permission_callback' => '__return_true',
      ]);
  }

  function rsh_handle_sync_order( WP_REST_Request $request ): WP_REST_Response {
      if ( get_option('rsh_enabled','yes') !== 'yes' ) return rsh_error('plugin_disabled','الإضافة معطّلة.',403);
      $stored_key   = get_option(RSH_OPTION_KEY,'');
      $provided_key = $request->get_header('X-Risha-Key') ?? $request->get_header('X-Aziz-Key') ?? $request->get_header('X-Falcon-Key') ?? $request->get_param('api_key') ?? '';
      if ( empty($stored_key) || !hash_equals($stored_key, trim($provided_key)) ) {
          rsh_log($request,null,'error','مفتاح API غير صحيح'); return rsh_error('invalid_api_key','مفتاح API غير صحيح.',401);
      }
      $body     = $request->get_json_params() ?: $request->get_params();
      $required = ['customer_name','customer_email','customer_phone','total_amount'];
      foreach ($required as $f) { if (empty($body[$f])) return rsh_error('missing_field',"حقل مطلوب: $f",422); }
      $customer_name  = sanitize_text_field($body['customer_name']);
      $customer_email = sanitize_email($body['customer_email']);
      $customer_phone = sanitize_text_field($body['customer_phone']);
      $product_name   = sanitize_text_field($body['product_name'] ?? 'اشتراك');
      $total_amount   = floatval($body['total_amount']);
      $quantity       = max(1,intval($body['quantity']??1));
      $order_ref      = sanitize_text_field($body['falcon_order_id']??$body['order_id']??'');
      $payment_gw     = sanitize_text_field($body['payment_gateway']??'');
      $notes          = sanitize_textarea_field($body['notes']??'');
      $return_url     = esc_url_raw($body['return_url']??'');
      if ($total_amount<=0) return rsh_error('invalid_amount','المبلغ غير صحيح.',422);
      if (!is_email($customer_email)) return rsh_error('invalid_email','البريد غير صحيح.',422);
      if ($order_ref) {
          $existing = wc_get_orders(['meta_key'=>'_rsh_order_ref','meta_value'=>$order_ref,'limit'=>1]);
          if (!empty($existing)) {
              $wc_order=$existing[0];
              return new WP_REST_Response(['success'=>true,'wc_order_id'=>$wc_order->get_id(),'payment_url'=>$wc_order->get_checkout_payment_url(),'order_status'=>$wc_order->get_status(),'message'=>'الطلب موجود.'],200);
          }
      }
      $customer_id=0; $user=get_user_by('email',$customer_email); if ($user) $customer_id=$user->ID;
      $wc_order=wc_create_order(['customer_id'=>$customer_id]);
      if (is_wp_error($wc_order)) { rsh_log($request,null,'error',$wc_order->get_error_message()); return rsh_error('order_creation_failed',$wc_order->get_error_message(),500); }
      $addr=['first_name'=>$customer_name,'last_name'=>'','email'=>$customer_email,'phone'=>$customer_phone,'address_1'=>'','city'=>'','country'=>'SA'];
      $wc_order->set_address($addr,'billing'); $wc_order->set_address($addr,'shipping');
      $fee=new WC_Order_Item_Fee(); $fee->set_name($product_name); $fee->set_amount($total_amount); $fee->set_tax_class(''); $fee->set_tax_status('none'); $fee->set_total($total_amount); $wc_order->add_item($fee);
      $wc_order->set_payment_method('risha_payment'); $wc_order->set_payment_method_title('دفع مباشر');
      $wc_order->set_currency(get_woocommerce_currency()); $wc_order->set_prices_include_tax(false); $wc_order->calculate_totals();
      $wc_order->set_status('pending','طلب مستلم');
      $wc_order->update_meta_data('_rsh_order_ref',$order_ref); $wc_order->update_meta_data('_rsh_qty',$quantity);
      $wc_order->update_meta_data('_rsh_gateway',$payment_gw); $wc_order->update_meta_data('_rsh_product',$product_name);
      $wc_order->update_meta_data('_falcon_order_id',$order_ref); $wc_order->update_meta_data('_falcon_return_url',$return_url);
      if ($return_url) $wc_order->update_meta_data('_rsh_return_url',$return_url);
      if ($notes) $wc_order->add_order_note('ملاحظات: '.$notes);
      $wc_order->save(); $wc_order_id=$wc_order->get_id();
      rsh_log(['name'=>$customer_name,'amount'=>$total_amount,'order_id'=>$order_ref,'product'=>$product_name,'quantity'=>$quantity],$wc_order_id,'ok');
      return new WP_REST_Response(['success'=>true,'wc_order_id'=>$wc_order_id,'payment_url'=>$wc_order->get_checkout_payment_url(),'order_key'=>$wc_order->get_order_key(),'order_status'=>$wc_order->get_status(),'total'=>$wc_order->get_total(),'currency'=>$wc_order->get_currency(),'message'=>'تم إنشاء الطلب بنجاح.'],201);
  }

  add_action('send_headers','rsh_allow_iframe');
  function rsh_allow_iframe() {
      if (!function_exists('is_wc_endpoint_url')) return;
      if (is_checkout()||is_wc_endpoint_url('order-pay')||is_wc_endpoint_url('order-received')) {
          header_remove('X-Frame-Options'); header('X-Frame-Options: ALLOWALL'); header('Content-Security-Policy: frame-ancestors *');
      }
  }

  add_action('woocommerce_thankyou','rsh_on_thankyou',5);
  function rsh_on_thankyou(int $order_id) {
      $order=$wc_order=wc_get_order($order_id);
      $order_ref=$order?($order->get_meta('_rsh_order_ref')?:$order->get_meta('_falcon_order_id')):'';
      $return_url=$order?($order->get_meta('_rsh_return_url')?:$order->get_meta('_falcon_return_url')):'';
      if (!$order_ref) return;
      $is_paid=in_array($order->get_status(),['processing','completed','on-hold'],true);
      ?>
      <script>(function(){var orderRef='<?php echo esc_js($order_ref); ?>';var wcOrderId=<?php echo intval($order_id); ?>;var isPaid=<?php echo $is_paid?'true':'false'; ?>;var returnUrl='<?php echo esc_js($return_url); ?>';var msg={type:'FALCON_PAYMENT_COMPLETE',falconOrderId:orderRef,wcOrderId:wcOrderId,isPaid:isPaid};try{if(window.parent&&window.parent!==window)window.parent.postMessage(msg,'*');}catch(e){}try{if(window.opener&&!window.opener.closed){window.opener.postMessage(msg,'*');setTimeout(function(){window.close();},1200);}}catch(e){}if(returnUrl&&!window.opener&&window.parent===window)setTimeout(function(){window.location.href=returnUrl;},2000);})();</script>
      <?php
  }

  add_action('woocommerce_order_status_changed','rsh_notify_on_payment',10,3);
  function rsh_notify_on_payment(int $order_id,string $from,string $to) {
      if (!in_array($to,['processing','completed'],true)) return;
      $order=wc_get_order($order_id); $order_ref=$order?($order->get_meta('_rsh_order_ref')?:$order->get_meta('_falcon_order_id')):'';
      if (!$order_ref) return;
      $store_url=rtrim(get_option('rsh_store_url',''),'/');
      if (!$store_url) return;
      if (strpos($store_url,'http')!==0) $store_url='https://'.$store_url;
      wp_remote_post($store_url.'/api/orders/direct-checkout/paid',['body'=>wp_json_encode(['falcon_order_id'=>$order_ref,'wc_order_id'=>$order_id,'api_key'=>get_option(RSH_OPTION_KEY,'')]),'headers'=>['Content-Type'=>'application/json'],'timeout'=>15,'blocking'=>false]);
  }

  add_action('woocommerce_admin_order_data_after_billing_address','rsh_show_order_meta');
  function rsh_show_order_meta(WC_Order $order) {
      $ref=$order->get_meta('_rsh_order_ref')?:$order->get_meta('_falcon_order_id');
      $product=$order->get_meta('_rsh_product')?:$order->get_meta('_falcon_product');
      $gateway=$order->get_meta('_rsh_gateway');
      if (!$ref) return;
      echo '<div style="background:#f0fff4;border:1px solid #9ae6b4;border-radius:6px;padding:10px 14px;margin-top:12px;font-size:13px;">';
      echo '<strong>✨ طلب مباشر</strong><br>';
      echo 'رقم الطلب: <code>'.esc_html($ref).'</code><br>';
      if ($product) echo 'الباقة: '.esc_html($product).'<br>';
      if ($gateway) echo 'طريقة الدفع: '.esc_html($gateway);
      echo '</div>';
  }

  function rsh_error(string $code,string $message,int $status=400):WP_REST_Response{return new WP_REST_Response(['success'=>false,'code'=>$code,'message'=>$message],$status);}

  function rsh_log($data,?int $wc_order_id,string $status,string $error=''){
      $log=(array)get_option(RSH_LOG_OPTION,[]);
      $log[] = ['date'=>wp_date('Y-m-d H:i:s'),'name'=>is_array($data)?($data['name']??''):'' ,'amount'=>is_array($data)?($data['amount']??''):'' ,'order_id'=>is_array($data)?($data['order_id']??''):'' ,'wc_order_id'=>$wc_order_id,'status'=>$status,'error'=>$error];
      if (count($log)>100) $log=array_slice($log,-100);
      update_option(RSH_LOG_OPTION,$log);
  }
  