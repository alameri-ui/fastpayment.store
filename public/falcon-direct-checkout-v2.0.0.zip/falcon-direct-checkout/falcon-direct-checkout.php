<?php
/**
 * Plugin Name:       Falcon Direct Checkout
 * Plugin URI:        https://alammari.digital
 * Description:       يربط متجر WooCommerce الخاص بك بمنصة Falcon IPTV ليتلقى الطلبات تلقائياً ويزامن بيانات العملاء بشكل كامل.
 * Version:           2.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            العامري ديجتال
 * Author URI:        https://alammari.digital
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       falcon-direct-checkout
 * Domain Path:       /languages
 * WC requires at least: 5.0
 * WC tested up to:   8.9
 */

defined( 'ABSPATH' ) || exit;

define( 'FDC_VERSION',     '2.0.0' );
define( 'FDC_PLUGIN_FILE', __FILE__ );
define( 'FDC_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'FDC_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'FDC_OPTION_KEY',  'fdc_api_key' );
define( 'FDC_LOG_OPTION',  'fdc_order_log' );

/* ──────────────────────────────────────────────────────────────────
   1.  ACTIVATION / DEACTIVATION
────────────────────────────────────────────────────────────────── */
register_activation_hook( FDC_PLUGIN_FILE, 'fdc_activate' );
function fdc_activate() {
    if ( ! get_option( FDC_OPTION_KEY ) ) {
        update_option( FDC_OPTION_KEY, fdc_generate_key() );
    }
    if ( ! get_option( FDC_LOG_OPTION ) ) {
        update_option( FDC_LOG_OPTION, [] );
    }
}

function fdc_generate_key(): string {
    return 'fdc_' . bin2hex( random_bytes( 24 ) );
}

/* ──────────────────────────────────────────────────────────────────
   2.  SETTINGS PAGE  (WooCommerce → Falcon Direct)
────────────────────────────────────────────────────────────────── */
add_filter( 'woocommerce_settings_tabs_array', 'fdc_add_settings_tab', 60 );
function fdc_add_settings_tab( $tabs ) {
    $tabs['falcon_direct'] = '🦅 Falcon Direct';
    return $tabs;
}

add_action( 'woocommerce_settings_tabs_falcon_direct', 'fdc_settings_page' );
function fdc_settings_page() {
    $api_key      = get_option( FDC_OPTION_KEY, '' );
    $endpoint_url = get_rest_url( null, 'falcon-direct/v1/sync-order' );
    $falcon_url   = get_option( 'fdc_falcon_url', '' );
    $enabled      = get_option( 'fdc_enabled', 'yes' );
    $log          = array_slice( array_reverse( (array) get_option( FDC_LOG_OPTION, [] ) ), 0, 20 );

    // Handle form save
    if ( isset( $_POST['fdc_save'] ) && check_admin_referer( 'fdc_settings' ) ) {
        $enabled    = sanitize_text_field( $_POST['fdc_enabled'] ?? 'no' );
        $falcon_url = esc_url_raw( $_POST['fdc_falcon_url'] ?? '' );
        update_option( 'fdc_enabled',    $enabled );
        update_option( 'fdc_falcon_url', $falcon_url );
        echo '<div class="updated"><p>✅ تم حفظ الإعدادات.</p></div>';
    }

    // Handle API key regeneration
    if ( isset( $_POST['fdc_regen'] ) && check_admin_referer( 'fdc_settings' ) ) {
        $api_key = fdc_generate_key();
        update_option( FDC_OPTION_KEY, $api_key );
        echo '<div class="updated"><p>🔑 تم توليد مفتاح API جديد. لا تنسَ تحديثه في لوحة Falcon IPTV.</p></div>';
    }

    ?>
    <style>
        .fdc-box { background:#fff; border:1px solid #ddd; border-radius:8px; padding:20px; margin:15px 0; }
        .fdc-box h3 { margin-top:0; color:#1e3a5f; display:flex; align-items:center; gap:8px; }
        .fdc-key-row { display:flex; gap:10px; align-items:center; margin-top:8px; }
        .fdc-key-row input { font-family:monospace; font-size:13px; flex:1; padding:8px 12px; border:1px solid #ccc; border-radius:6px; background:#f9f9f9; }
        .fdc-copy-btn { cursor:pointer; background:#0073aa; color:#fff; border:none; padding:8px 16px; border-radius:6px; font-size:13px; }
        .fdc-copy-btn:hover { background:#005d8e; }
        .fdc-log table { width:100%; border-collapse:collapse; font-size:12px; }
        .fdc-log th { background:#1e3a5f; color:#fff; padding:8px; text-align:right; }
        .fdc-log td { padding:7px 8px; border-bottom:1px solid #eee; }
        .fdc-log tr:hover td { background:#f7f7f7; }
        .fdc-badge-ok  { background:#d4edda; color:#155724; padding:2px 8px; border-radius:20px; font-size:11px; font-weight:600; }
        .fdc-badge-err { background:#f8d7da; color:#721c24; padding:2px 8px; border-radius:20px; font-size:11px; font-weight:600; }
    </style>

    <h2>🦅 Falcon Direct Checkout — الإعدادات</h2>

    <form method="post" action="">
        <?php wp_nonce_field( 'fdc_settings' ); ?>

        <!-- ─── Connection Info ─── -->
        <div class="fdc-box">
            <h3>🔗 معلومات الاتصال</h3>
            <p style="color:#555">انسخ الرابط ومفتاح API أدناه وأضفهما في لوحة إدارة <strong>Falcon IPTV</strong> تحت إعدادات بوابة "الدفع المباشر".</p>

            <table class="form-table">
                <tr>
                    <th>🌐 رابط الـ Endpoint</th>
                    <td>
                        <div class="fdc-key-row">
                            <input type="text" id="fdc_endpoint" value="<?php echo esc_attr( $endpoint_url ); ?>" readonly />
                            <button type="button" class="fdc-copy-btn" onclick="fdcCopy('fdc_endpoint')">نسخ</button>
                        </div>
                        <p class="description">أضف هذا الرابط في حقل "Redirect URL" لبوابة الدفع المباشر في Falcon IPTV.</p>
                    </td>
                </tr>
                <tr>
                    <th>🔑 مفتاح API</th>
                    <td>
                        <div class="fdc-key-row">
                            <input type="text" id="fdc_api_key_display" value="<?php echo esc_attr( $api_key ); ?>" readonly />
                            <button type="button" class="fdc-copy-btn" onclick="fdcCopy('fdc_api_key_display')">نسخ</button>
                        </div>
                        <p class="description">أضف هذا المفتاح في حقل "API Key" لبوابة الدفع المباشر في Falcon IPTV.</p>
                        <button type="submit" name="fdc_regen" class="button" style="margin-top:8px">🔄 توليد مفتاح جديد</button>
                        <span style="color:#c0392b; font-size:12px; margin-right:8px">⚠️ عند التوليد يجب تحديث المفتاح في Falcon IPTV.</span>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ─── General Settings ─── -->
        <div class="fdc-box">
            <h3>⚙️ الإعدادات العامة</h3>
            <table class="form-table">
                <tr>
                    <th>تفعيل الإضافة</th>
                    <td>
                        <label>
                            <input type="checkbox" name="fdc_enabled" value="yes" <?php checked( $enabled, 'yes' ); ?> />
                            تفعيل استقبال الطلبات من Falcon IPTV
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>🦅 رابط منصة Falcon IPTV</th>
                    <td>
                        <input type="url" name="fdc_falcon_url" value="<?php echo esc_attr( $falcon_url ); ?>"
                               class="regular-text" placeholder="https://your-falcon-store.com" />
                        <p class="description">اختياري — يُستخدم لإرسال تأكيد الدفع مستقبلاً.</p>
                    </td>
                </tr>
            </table>
        </div>

        <button type="submit" name="fdc_save" class="button button-primary button-large">💾 حفظ الإعدادات</button>
    </form>

    <!-- ─── Recent Orders Log ─── -->
    <div class="fdc-box fdc-log" style="margin-top:30px">
        <h3>📋 آخر الطلبات المُستلمة</h3>
        <?php if ( empty( $log ) ) : ?>
            <p style="color:#888">لا توجد طلبات مُستلمة بعد.</p>
        <?php else : ?>
            <table>
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>اسم العميل</th>
                        <th>المبلغ</th>
                        <th>رقم طلب Falcon</th>
                        <th>رقم طلب WooCommerce</th>
                        <th>الحالة</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $log as $entry ) : ?>
                        <tr>
                            <td><?php echo esc_html( $entry['date'] ?? '—' ); ?></td>
                            <td><?php echo esc_html( $entry['name'] ?? '—' ); ?></td>
                            <td><?php echo esc_html( $entry['amount'] ?? '—' ); ?> ر.س</td>
                            <td><?php echo esc_html( $entry['falcon_order_id'] ?? '—' ); ?></td>
                            <td>
                                <?php if ( ! empty( $entry['wc_order_id'] ) ) : ?>
                                    <a href="<?php echo esc_url( admin_url( 'post.php?post=' . $entry['wc_order_id'] . '&action=edit' ) ); ?>">
                                        #<?php echo esc_html( $entry['wc_order_id'] ); ?>
                                    </a>
                                <?php else : echo '—'; endif; ?>
                            </td>
                            <td>
                                <?php if ( ( $entry['status'] ?? '' ) === 'ok' ) : ?>
                                    <span class="fdc-badge-ok">✅ ناجح</span>
                                <?php else : ?>
                                    <span class="fdc-badge-err">❌ <?php echo esc_html( $entry['error'] ?? 'خطأ' ); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <p style="color:#888; font-size:12px; margin-top:20px; text-align:center">
        Falcon Direct Checkout v<?php echo FDC_VERSION; ?> — جميع الحقوق محفوظة لـ <strong>العامري ديجتال</strong> &copy; <?php echo date('Y'); ?>
    </p>

    <script>
    function fdcCopy(id) {
        var el = document.getElementById(id);
        el.select(); el.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(el.value).then(function() {
            alert('✅ تم النسخ!');
        }).catch(function() {
            document.execCommand('copy');
            alert('✅ تم النسخ!');
        });
    }
    </script>
    <?php
}

/* ──────────────────────────────────────────────────────────────────
   3.  REST API ENDPOINT  —  POST /wp-json/falcon-direct/v1/sync-order
────────────────────────────────────────────────────────────────── */
add_action( 'rest_api_init', 'fdc_register_routes' );
function fdc_register_routes() {
    register_rest_route( 'falcon-direct/v1', '/sync-order', [
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'fdc_handle_sync_order',
        'permission_callback' => '__return_true',
    ] );

    // Health-check endpoint
    register_rest_route( 'falcon-direct/v1', '/ping', [
        'methods'             => WP_REST_Server::READABLE,
        'callback'            => function() {
            return new WP_REST_Response( [
                'status'  => 'ok',
                'plugin'  => 'Falcon Direct Checkout',
                'version' => FDC_VERSION,
                'store'   => get_bloginfo( 'name' ),
            ], 200 );
        },
        'permission_callback' => '__return_true',
    ] );
}

function fdc_handle_sync_order( WP_REST_Request $request ): WP_REST_Response {
    // ── 1. Check plugin is enabled ──────────────────────────────
    if ( get_option( 'fdc_enabled', 'yes' ) !== 'yes' ) {
        return fdc_error( 'plugin_disabled', 'الإضافة معطّلة من الإعدادات.', 403 );
    }

    // ── 2. Validate API key ─────────────────────────────────────
    $stored_key   = get_option( FDC_OPTION_KEY, '' );
    $provided_key = $request->get_header( 'X-Falcon-Key' )
        ?? $request->get_param( 'api_key' )
        ?? '';

    if ( empty( $stored_key ) || ! hash_equals( $stored_key, trim( $provided_key ) ) ) {
        fdc_log_entry( $request, null, 'error', 'مفتاح API غير صحيح' );
        return fdc_error( 'invalid_api_key', 'مفتاح API غير صحيح أو مفقود.', 401 );
    }

    // ── 3. Extract & validate payload ──────────────────────────
    $body = $request->get_json_params() ?: $request->get_params();

    $required = [ 'customer_name', 'customer_email', 'customer_phone', 'total_amount' ];
    foreach ( $required as $field ) {
        if ( empty( $body[ $field ] ) ) {
            return fdc_error( 'missing_field', "الحقل المطلوب مفقود: $field", 422 );
        }
    }

    $customer_name    = sanitize_text_field( $body['customer_name'] );
    $customer_email   = sanitize_email( $body['customer_email'] );
    $customer_phone   = sanitize_text_field( $body['customer_phone'] );
    $product_name     = sanitize_text_field( $body['product_name'] ?? 'اشتراك Falcon IPTV' );
    $total_amount     = floatval( $body['total_amount'] );
    $quantity         = max( 1, intval( $body['quantity'] ?? 1 ) );
    $falcon_order_id  = sanitize_text_field( $body['falcon_order_id'] ?? '' );
    $payment_gateway  = sanitize_text_field( $body['payment_gateway'] ?? '' );
    $notes            = sanitize_textarea_field( $body['notes'] ?? '' );

    if ( $total_amount <= 0 ) {
        return fdc_error( 'invalid_amount', 'المبلغ الإجمالي غير صحيح.', 422 );
    }

    if ( ! is_email( $customer_email ) ) {
        return fdc_error( 'invalid_email', 'البريد الإلكتروني غير صحيح.', 422 );
    }

    // ── 4. Prevent duplicate orders ─────────────────────────────
    if ( $falcon_order_id ) {
        $existing = wc_get_orders( [
            'meta_key'   => '_falcon_order_id',
            'meta_value' => $falcon_order_id,
            'limit'      => 1,
        ] );
        if ( ! empty( $existing ) ) {
            $wc_order = $existing[0];
            return new WP_REST_Response( [
                'success'      => true,
                'wc_order_id'  => $wc_order->get_id(),
                'payment_url'  => $wc_order->get_checkout_payment_url(),
                'order_status' => $wc_order->get_status(),
                'message'      => 'الطلب موجود مسبقاً.',
            ], 200 );
        }
    }

    // ── 5. Find or create WooCommerce customer ──────────────────
    $customer_id = 0;
    $user        = get_user_by( 'email', $customer_email );
    if ( $user ) {
        $customer_id = $user->ID;
    }

    // ── 6. Build & create WooCommerce order ────────────────────
    $wc_order = wc_create_order( [ 'customer_id' => $customer_id ] );

    if ( is_wp_error( $wc_order ) ) {
        fdc_log_entry( $request, null, 'error', $wc_order->get_error_message() );
        return fdc_error( 'order_creation_failed', $wc_order->get_error_message(), 500 );
    }

    // Address
    $address = [
        'first_name' => $customer_name,
        'last_name'  => '',
        'email'      => $customer_email,
        'phone'      => $customer_phone,
        'address_1'  => '',
        'city'       => '',
        'country'    => 'SA',
    ];
    $wc_order->set_address( $address, 'billing' );
    $wc_order->set_address( $address, 'shipping' );

    // Add a fee line for the subscription (no real product needed)
    $fee = new WC_Order_Item_Fee();
    $fee->set_name( $product_name );
    $fee->set_amount( $total_amount );
    $fee->set_tax_class( '' );
    $fee->set_tax_status( 'none' );
    $fee->set_total( $total_amount );
    $wc_order->add_item( $fee );

    // Payment method
    $wc_order->set_payment_method( 'falcon_direct' );
    $wc_order->set_payment_method_title( 'Falcon Direct — ' . $payment_gateway );

    // Totals
    $wc_order->set_currency( get_woocommerce_currency() );
    $wc_order->set_prices_include_tax( false );
    $wc_order->calculate_totals();

    // Status & meta
    $wc_order->set_status( 'pending', 'طلب مُستلم من Falcon IPTV' );
    $wc_order->update_meta_data( '_falcon_order_id',   $falcon_order_id );
    $wc_order->update_meta_data( '_falcon_qty',        $quantity );
    $wc_order->update_meta_data( '_falcon_gateway',    $payment_gateway );
    $wc_order->update_meta_data( '_falcon_product',    $product_name );
    if ( $notes ) {
        $wc_order->add_order_note( 'ملاحظات من Falcon: ' . $notes );
    }

    $wc_order->save();
    $wc_order_id = $wc_order->get_id();

    // ── 7. Log the entry ────────────────────────────────────────
    fdc_log_entry( [
        'name'            => $customer_name,
        'email'           => $customer_email,
        'amount'          => $total_amount,
        'falcon_order_id' => $falcon_order_id,
        'product'         => $product_name,
        'quantity'        => $quantity,
    ], $wc_order_id, 'ok' );

    // ── 8. Return success response ─────────────────────────────
    return new WP_REST_Response( [
        'success'      => true,
        'wc_order_id'  => $wc_order_id,
        'payment_url'  => $wc_order->get_checkout_payment_url(),
        'order_key'    => $wc_order->get_order_key(),
        'order_status' => $wc_order->get_status(),
        'total'        => $wc_order->get_total(),
        'currency'     => $wc_order->get_currency(),
        'message'      => 'تم إنشاء الطلب بنجاح في WooCommerce.',
    ], 201 );
}

/* ──────────────────────────────────────────────────────────────────
   4.  ORDER META IN ADMIN  (show Falcon Order ID in WC order screen)
────────────────────────────────────────────────────────────────── */
add_action( 'woocommerce_admin_order_data_after_billing_address', 'fdc_show_order_meta_in_admin' );
function fdc_show_order_meta_in_admin( WC_Order $order ) {
    $falcon_id = $order->get_meta( '_falcon_order_id' );
    $gateway   = $order->get_meta( '_falcon_gateway' );
    $product   = $order->get_meta( '_falcon_product' );
    if ( ! $falcon_id ) return;
    echo '<div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:10px 14px;margin-top:12px;font-size:13px;">';
    echo '<strong>🦅 Falcon IPTV</strong><br>';
    echo 'رقم الطلب: <code>' . esc_html( $falcon_id ) . '</code><br>';
    if ( $product ) echo 'الباقة: ' . esc_html( $product ) . '<br>';
    if ( $gateway ) echo 'طريقة الدفع: ' . esc_html( $gateway );
    echo '</div>';
}

/* ──────────────────────────────────────────────────────────────────
   5.  HELPERS
────────────────────────────────────────────────────────────────── */
function fdc_error( string $code, string $message, int $status = 400 ): WP_REST_Response {
    return new WP_REST_Response( [ 'success' => false, 'code' => $code, 'message' => $message ], $status );
}

function fdc_log_entry( $data, ?int $wc_order_id, string $status, string $error = '' ) {
    $log   = (array) get_option( FDC_LOG_OPTION, [] );
    $log[] = [
        'date'            => wp_date( 'Y-m-d H:i:s' ),
        'name'            => is_array( $data ) ? ( $data['name'] ?? '' ) : '',
        'amount'          => is_array( $data ) ? ( $data['amount'] ?? '' ) : '',
        'falcon_order_id' => is_array( $data ) ? ( $data['falcon_order_id'] ?? '' ) : '',
        'wc_order_id'     => $wc_order_id,
        'status'          => $status,
        'error'           => $error,
    ];
    // Keep max 100 entries
    if ( count( $log ) > 100 ) {
        $log = array_slice( $log, -100 );
    }
    update_option( FDC_LOG_OPTION, $log );
}
