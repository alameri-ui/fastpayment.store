=== Falcon Direct Checkout ===
Contributors: alammari-digital
Tags: woocommerce, iptv, falcon, payment, sync
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

تكامل مباشر بين منصة Falcon IPTV ومتجر WooCommerce لاستقبال الطلبات وتزامن بيانات العملاء تلقائياً.

== Description ==

**Falcon Direct Checkout** إضافة WooCommerce تُمكّن منصة Falcon IPTV من إرسال طلبات الاشتراك مباشرةً إلى متجرك بشكل آلي وآمن.

= الميزات الرئيسية =

* **توليد مفتاح API** — مفتاح فريد وآمن يُستخدم للتحقق من كل طلب وارد.
* **نقطة اتصال REST** — `POST /wp-json/falcon-direct/v1/sync-order` لاستقبال الطلبات.
* **منع التكرار** — كشف الطلبات المكررة تلقائياً عبر معرّف طلب Falcon.
* **بيانات العميل الكاملة** — الاسم، البريد، الجوال، الباقة، المبلغ، الكمية.
* **سجل الطلبات** — عرض آخر 20 طلباً مستلماً في صفحة الإعدادات.
* **صفحة إعدادات WooCommerce** — تحت WooCommerce ← Falcon Direct.

= طريقة الربط =

1. ثبّت الإضافة وفعّلها.
2. اذهب إلى **WooCommerce ← Falcon Direct**.
3. انسخ **رابط الـ Endpoint** و**مفتاح API**.
4. الصقهما في لوحة **Falcon IPTV** تحت إعدادات بوابة "الدفع المباشر".
5. من الآن فصاعداً تُنشأ الطلبات في متجرك تلقائياً عند كل عملية شراء.

= صيغة الطلب (Request Body) =

```json
{
  "api_key":         "fdc_xxxx",          // أو عبر header: X-Falcon-Key
  "customer_name":   "أحمد محمد",
  "customer_email":  "ahmed@example.com",
  "customer_phone":  "0501234567",
  "product_name":    "باقة فالكون الترا",
  "total_amount":    199,
  "quantity":        1,
  "falcon_order_id": "ORD-001",
  "payment_gateway": "mada",
  "notes":           ""
}
```

= الاستجابة (Response) =

```json
{
  "success":      true,
  "wc_order_id":  1234,
  "payment_url":  "https://yourstore.com/checkout/order-pay/1234/",
  "order_status": "pending",
  "total":        199,
  "currency":     "SAR"
}
```

== Installation ==

1. ارفع المجلد `falcon-direct-checkout` إلى `/wp-content/plugins/`.
2. فعّل الإضافة من **الإضافات** في لوحة WordPress.
3. اذهب إلى **WooCommerce ← Falcon Direct** لإعداد الاتصال.

== Changelog ==

= 2.0.0 =
* إضافة صفحة إعدادات متكاملة.
* توليد مفتاح API من داخل الإضافة.
* إضافة سجل الطلبات المستلمة.
* منع تكرار الطلبات تلقائياً.
* عرض بيانات Falcon IPTV في صفحة الطلب داخل WooCommerce.
* إضافة Endpoint للفحص: GET /wp-json/falcon-direct/v1/ping.

= 1.0.0 =
* الإصدار الأول.

== Frequently Asked Questions ==

= هل يتطلب WooCommerce؟ =
نعم، يجب تثبيت WooCommerce وتفعيله قبل هذه الإضافة.

= هل البيانات مشفّرة؟ =
يُنصح باستخدام HTTPS على موقعك. جميع الطلبات تمر بالتحقق من مفتاح API.

= هل يمكن إعادة توليد المفتاح؟ =
نعم، من صفحة الإعدادات يمكن توليد مفتاح جديد في أي وقت، مع ضرورة تحديثه في Falcon IPTV.

== Credits ==

جميع الحقوق محفوظة لـ **العامري ديجتال** © 2025
